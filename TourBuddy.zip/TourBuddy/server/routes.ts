import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBookingSchema } from "@shared/schema";
import { z } from "zod";
import { sendBookingConfirmationSMS } from "./sms";

export async function registerRoutes(app: Express): Promise<Server> {
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Create booking
  app.post("/api/bookings", async (req, res) => {
    try {
      const validatedData = insertBookingSchema.parse(req.body);
      const booking = await storage.createBooking(validatedData);
      
      console.log(`New booking created: ${booking.id} for ${booking.phoneNumber}`);
      
      // Send SMS confirmation
      const smsSuccess = await sendBookingConfirmationSMS(booking.phoneNumber, {
        id: booking.id,
        city: booking.city,
        beach: booking.beach,
        duration: booking.duration,
        price: booking.price
      });
      
      const confirmationMessage = `Booking confirmed! Your eFoil session in ${booking.city} at ${booking.beach} (${booking.duration} min) for €${booking.price} is reserved. Booking ID: ${booking.id}. ${smsSuccess ? 'Confirmation SMS sent to your phone.' : 'We\'ll contact you soon to schedule.'}`;
      
      res.json({ 
        success: true, 
        booking,
        message: confirmationMessage,
        smsSent: smsSuccess
      });
    } catch (error) {
      console.log(`Booking error: ${error}`);
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          success: false, 
          error: "Invalid booking data", 
          details: error.errors 
        });
      } else {
        res.status(500).json({ 
          success: false, 
          error: "Failed to create booking" 
        });
      }
    }
  });

  // Get booking by ID
  app.get("/api/bookings/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const booking = await storage.getBooking(id);
      
      if (!booking) {
        res.status(404).json({ success: false, error: "Booking not found" });
        return;
      }
      
      res.json({ success: true, booking });
    } catch (error) {
      console.log(`Get booking error: ${error}`);
      res.status(500).json({ success: false, error: "Failed to get booking" });
    }
  });

  // Confirm booking
  app.patch("/api/bookings/:id/confirm", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const booking = await storage.confirmBooking(id);
      
      if (!booking) {
        res.status(404).json({ success: false, error: "Booking not found" });
        return;
      }
      
      console.log(`Booking confirmed: ${booking.id}`);
      res.json({ success: true, booking });
    } catch (error) {
      console.log(`Confirm booking error: ${error}`);
      res.status(500).json({ success: false, error: "Failed to confirm booking" });
    }
  });

  // Debug SMS endpoint
  app.post("/api/test-sms", async (req, res) => {
    try {
      const { phoneNumber } = req.body;
      
      if (!phoneNumber) {
        res.status(400).json({ success: false, error: "Phone number required" });
        return;
      }

      const testBooking = {
        id: 999,
        city: "saint-tropez",
        beach: "Test Beach",
        duration: 30,
        price: "79"
      };

      const smsSuccess = await sendBookingConfirmationSMS(phoneNumber, testBooking);
      
      res.json({ 
        success: true, 
        smsSent: smsSuccess,
        message: smsSuccess ? "Test SMS sent successfully" : "Failed to send test SMS"
      });
    } catch (error) {
      console.log(`Test SMS error: ${error}`);
      res.status(500).json({ success: false, error: "Failed to send test SMS" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
