import twilio from 'twilio';

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const fromPhoneNumber = process.env.TWILIO_PHONE_NUMBER;

if (!accountSid || !authToken || !fromPhoneNumber) {
  console.warn('Twilio credentials missing. SMS functionality will be disabled.');
  console.warn(`AccountSid: ${accountSid ? 'Set' : 'Missing'}`);
  console.warn(`AuthToken: ${authToken ? 'Set' : 'Missing'}`);
  console.warn(`PhoneNumber: ${fromPhoneNumber ? 'Set' : 'Missing'}`);
} else {
  console.log('Twilio SMS service initialized successfully');
}

const client = accountSid && authToken ? twilio(accountSid, authToken) : null;

export async function sendBookingConfirmationSMS(
  phoneNumber: string,
  bookingDetails: {
    id: number;
    city: string;
    beach: string;
    duration: number;
    price: string;
  }
): Promise<boolean> {
  if (!client || !fromPhoneNumber) {
    console.log('SMS service not configured. Skipping SMS send.');
    return false;
  }

  try {
    console.log(`Attempting to send SMS to ${phoneNumber} from ${fromPhoneNumber}`);
    
    const message = `Roll'n'Trip Booking Confirmed!

Location: ${bookingDetails.beach}, ${bookingDetails.city}
Duration: ${bookingDetails.duration} minutes
Price: €${bookingDetails.price}
Booking ID: ${bookingDetails.id}

We'll contact you soon to schedule your eFoil session!

Questions? Call +33 6 98 74 33 39`;

    const result = await client.messages.create({
      body: message,
      from: fromPhoneNumber,
      to: phoneNumber,
    });

    console.log(`SMS sent successfully to ${phoneNumber}. SID: ${result.sid}`);
    console.log(`Message status: ${result.status}`);
    console.log(`Error code: ${result.errorCode || 'None'}`);
    console.log(`Error message: ${result.errorMessage || 'None'}`);
    
    // Check message status after a brief delay
    setTimeout(async () => {
      try {
        const messageStatus = await client.messages(result.sid).fetch();
        console.log(`Updated SMS status for ${result.sid}: ${messageStatus.status}`);
        if (messageStatus.errorCode) {
          console.log(`SMS Error: ${messageStatus.errorCode} - ${messageStatus.errorMessage}`);
        }
      } catch (error) {
        console.log('Could not fetch message status:', error);
      }
    }, 5000);
    
    return true;
  } catch (error) {
    console.error('Failed to send SMS:', error);
    if (error.code) {
      console.error(`Twilio Error Code: ${error.code}`);
    }
    if (error.moreInfo) {
      console.error(`More info: ${error.moreInfo}`);
    }
    return false;
  }
}