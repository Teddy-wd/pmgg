# Roll'n'Trip eFoil Booking System

## Overview

This is a full-stack eFoil activity booking application built for the Saint Tropez region. It's an Express.js backend with a React frontend, designed as a modern booking platform similar to GetYourGuide. The application allows users to browse eFoil experiences and make bookings with integrated SMS notifications.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack Query (React Query) for server state
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **Build Tool**: Vite for development and production builds
- **Component Library**: Radix UI primitives with custom styling

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js 20
- **Module System**: ES Modules
- **Session Management**: Basic request/response handling with JSON middleware

### Database Architecture
- **ORM**: Drizzle ORM with TypeScript schema definitions
- **Database**: PostgreSQL (configured for Neon serverless)
- **Migration System**: Drizzle Kit for schema management
- **Connection**: Connection pooling with @neondatabase/serverless

## Key Components

### Database Schema (`shared/schema.ts`)
- **Users Table**: Basic user authentication with username/password
- **Bookings Table**: Core booking entity with phone, location, duration, pricing, and confirmation status
- **Validation**: Zod schemas for runtime type checking and API validation

### API Routes (`server/routes.ts`)
- **Health Check**: `/api/health` for system monitoring
- **Booking Creation**: `POST /api/bookings` with validation and SMS integration
- **Error Handling**: Structured error responses with appropriate HTTP status codes

### Frontend Pages
- **Home Page**: Main eFoil booking interface with image gallery, pricing, and booking form
- **404 Page**: Basic error handling for unknown routes

### SMS Integration (`server/sms.ts`)
- **Provider**: Twilio SMS service
- **Functionality**: Booking confirmation messages with activity details
- **Fallback**: Graceful handling when SMS credentials are not configured

## Data Flow

1. **User Interaction**: User fills out booking form on homepage
2. **Form Validation**: Client-side validation using Zod schemas
3. **API Request**: POST to `/api/bookings` with booking details
4. **Server Processing**: 
   - Validate request data
   - Store booking in PostgreSQL database
   - Send SMS confirmation via Twilio
5. **Response**: Return booking confirmation with success status
6. **UI Update**: Display confirmation message to user

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React, React DOM, TanStack Query for state management
- **UI Components**: Radix UI primitives, Tailwind CSS, shadcn/ui components
- **Development**: Vite, TypeScript, PostCSS, Autoprefixer

### Backend Dependencies
- **Database**: Drizzle ORM, @neondatabase/serverless, connect-pg-simple
- **Validation**: Zod for schema validation, drizzle-zod for ORM integration
- **Communication**: Twilio for SMS (configured but optional)
- **Utilities**: date-fns for date handling, various utility libraries

### Development Tools
- **Build**: esbuild for server bundling, Vite for client bundling
- **Database**: drizzle-kit for migrations and schema management
- **Linting/Formatting**: TypeScript compiler for type checking

## Deployment Strategy

### Platform Configuration
- **Hosting**: Replit with autoscale deployment
- **Database**: PostgreSQL 16 module (likely Neon serverless in production)
- **Port Configuration**: Internal port 5000, external port 80
- **Build Process**: `npm run build` creates production assets
- **Start Command**: `npm run start` for production server

### Environment Variables Required
- `DATABASE_URL`: PostgreSQL connection string
- `TWILIO_ACCOUNT_SID`: Twilio account identifier (optional)
- `TWILIO_AUTH_TOKEN`: Twilio authentication token (optional)  
- `TWILIO_PHONE_NUMBER`: Sender phone number for SMS (optional)

### Production Build Process
1. Vite builds React frontend to `dist/public`
2. esbuild bundles Express server to `dist/index.js`
3. Static assets served by Express in production
4. Database migrations applied via `npm run db:push`

## Changelog

- June 13, 2025. Initial setup

## User Preferences

Preferred communication style: Simple, everyday language.