import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import BookingForm from "@/components/booking-form";
import { 
  Phone,
  Clock, 
  Languages, 
  Car, 
  Users, 
  CheckCircle, 
  Info, 
  Check, 
  X, 
  AlertTriangle,
  ChevronDown
} from "lucide-react";

export default function Home() {
  const [showFullDescription, setShowFullDescription] = useState(false);

  const highlights = [
    "Feel the thrill of gliding over the water on an electric surfboard",
    "Discover the hidden beauty of the Calanques from a unique sea perspective", 
    "Explore secluded coves and secret beaches that are inaccessible by land",
    "Learn the basics of electric surfing from a local guide and practice at your own pace",
    "Capture every unforgettable moment with professional photos and videos"
  ];

  const included = [
    "Photos and videos",
    "Safety briefing", 
    "Practice ride time (eFoil)",
    "Calanques Explorations by Sea",
    "Guide"
  ];

  const notIncluded = [
    "Hotel pickup and drop-off (available on request)"
  ];

  const notSuitableFor = [
    "Children under 12 years",
    "Pregnant women",
    "People with heart problems", 
    "Non-swimmers",
    "People prone to seasickness"
  ];

  const whatToBring = [
    "Swimwear",
    "Towel",
    "Snacks", 
    "Sunscreen"
  ];



  return (
    <div className="min-h-screen bg-white font-sora">
      {/* Header */}
      <header className="bg-black text-white">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <a href="/" className="flex items-center">
              <img 
                src="https://i.ibb.co/RMG26p5/image-4.png" 
                alt="Roll'n'Trip Logo" 
                className="h-10"
              />
            </a>
            
            <div className="hidden md:flex items-center space-x-6">
              <span className="text-rollntrip-teal font-medium">Book a session</span>
              <a href="/about-us" className="hover:text-gray-300">About us</a>
              <a href="/contact" className="hover:text-gray-300">Contact</a>
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4" />
                <span>+33 6 98 74 33 39</span>
              </div>
              <div className="flex space-x-2">
                <span>🇫🇷</span>
                <span>🇬🇧</span>
                <span>🇩🇪</span>
              </div>
            </div>
          </div>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="relative py-24 overflow-hidden">
        {/* Background Image */}
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&h=1200')`
          }}
        >
          {/* Dark overlay for text readability */}
          <div className="absolute inset-0 bg-black bg-opacity-40"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-4xl mx-auto text-center px-4">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-4 drop-shadow-lg">
            Book your eFoil session
          </h1>
          <p className="text-xl md:text-2xl text-white mb-8 drop-shadow-md">
            Saint Tropez: Learn how to Surf with an eFoil
          </p>
          <div className="flex justify-center">
            <ChevronDown className="h-8 w-8 text-white animate-bounce drop-shadow-md" />
          </div>
        </div>
      </section>

      {/* Image Strip */}
      <section className="py-8 bg-gray-50 overflow-hidden">
        <div className="flex space-x-4 animate-scroll">
          {[
            "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
            "https://images.unsplash.com/photo-1530549387789-4c1017266635?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
            "https://images.unsplash.com/photo-1583212292454-1fe6229603b7?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
            "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
            "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
            "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300",
            "https://images.unsplash.com/photo-1530549387789-4c1017266635?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300"
          ].map((src, index) => (
            <img
              key={index}
              src={src}
              alt={`eFoil session ${index + 1}`}
              className="w-80 h-48 object-cover rounded-lg flex-shrink-0"
            />
          ))}
        </div>
      </section>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Left Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Description */}
            <div className="text-center lg:text-left">
              <p className="text-xl text-gray-700 leading-relaxed mb-8">
                Glide over the crystal-clear waters of the Côte d'Azur on an electric surfboard (eFoil). Discover hidden coves and secret beaches that are inaccessible by land.
              </p>
            </div>

            {/* Activity Features */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl">
                <Clock className="text-black h-5 w-5" />
                <div>
                  <div className="text-sm font-semibold text-gray-900">Duration</div>
                  <div className="text-sm text-gray-600">30-90 minutes</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl">
                <Languages className="text-black h-5 w-5" />
                <div>
                  <div className="text-sm font-semibold text-gray-900">Languages</div>
                  <div className="text-sm text-gray-600">French, English, German</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl">
                <Car className="text-black h-5 w-5" />
                <div>
                  <div className="text-sm font-semibold text-gray-900">We bring boards</div>
                  <div className="text-sm text-gray-600">To your location</div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 p-4 bg-gray-50 rounded-xl">
                <Users className="text-black h-5 w-5" />
                <div>
                  <div className="text-sm font-semibold text-gray-900">Group size</div>
                  <div className="text-sm text-gray-600">Max. 6 people</div>
                </div>
              </div>
            </div>

            {/* Highlights */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Highlights</h2>
                <ul className="space-y-4">
                  {highlights.map((highlight, index) => (
                    <li key={index} className="flex items-start space-x-3">
                      <CheckCircle className="text-green-600 mt-1 h-5 w-5 flex-shrink-0" />
                      <span className="text-gray-700">{highlight}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Full Description */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Full description</h2>
                <div className="text-gray-700 leading-relaxed">
                  <p className="mb-4">
                    Escape the busy streets of Saint Tropez, Port Grimaud or even Fréjus and start foiling (surfing) effortlessly along the stunning Mediterranean coastline on a quiet, eco-friendly electric surfboard, guided by a local expert, and reach secluded coves and secret beaches that are inaccessible by land.
                  </p>
                  {showFullDescription && (
                    <div>
                      <p className="mb-4">
                        Your adventure begins with a comprehensive safety briefing and equipment introduction. Our certified instructors will teach you the fundamentals of eFoil operation, ensuring you feel confident before entering the water. The electric surfboard technology allows riders of all skill levels to experience the sensation of flying above the water.
                      </p>
                      <p className="mb-4">
                        As you glide across the pristine waters of the French Riviera, you'll discover hidden gems along the coastline that are only accessible by sea. The silent electric motor ensures minimal environmental impact while maximizing your connection with nature.
                      </p>
                    </div>
                  )}
                  <Button 
                    variant="link" 
                    className="text-black hover:text-gray-700 p-0 h-auto underline font-medium"
                    onClick={() => setShowFullDescription(!showFullDescription)}
                  >
                    {showFullDescription ? 'See less' : 'See more'}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* What's Included */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">What's included</h2>
                <div className="space-y-3">
                  {included.map((item, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <Check className="text-green-600 h-5 w-5" />
                      <span className="text-gray-700">{item}</span>
                    </div>
                  ))}
                  {notIncluded.map((item, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <X className="text-red-500 h-5 w-5" />
                      <span className="text-gray-700">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Not Suitable For */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                  <AlertTriangle className="text-red-500 mr-3 h-6 w-6" />
                  Not suitable for
                </h2>
                <div className="space-y-3">
                  {notSuitableFor.map((item, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <X className="text-red-500 h-5 w-5" />
                      <span className="text-gray-700">{item}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Important Information */}
            <Card className="border-0 shadow-sm">
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-6">Important information</h2>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-4">What to bring</h3>
                  <div className="space-y-2">
                    {whatToBring.map((item, index) => (
                      <div key={index} className="flex items-center space-x-3">
                        <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                        <span className="text-gray-700">{item}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Booking Section */}
          <div className="lg:col-span-1">
            <BookingForm />
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-black text-white py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>&copy; 2025 Roll'n'Trip - ☎️ +33 6 98 74 33 39</p>
        </div>
      </footer>
    </div>
  );
}