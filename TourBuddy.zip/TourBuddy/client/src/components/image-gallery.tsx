import { useState } from "react";
import { Plus } from "lucide-react";

const images = [
  {
    src: "https://images.unsplash.com/photo-1544197150-b99a580bb7a8?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1200&h=800",
    alt: "Person eFoil surfing above Mediterranean waters"
  },
  {
    src: "https://images.unsplash.com/photo-1530549387789-4c1017266635?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    alt: "Aerial view of eFoil surfers on turquoise waters"
  },
  {
    src: "https://images.unsplash.com/photo-1583212292454-1fe6229603b7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    alt: "Underwater view of eFoil hydrofoil in clear water"
  },
  {
    src: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    alt: "Group learning water sports with instructor"
  },
  {
    src: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=600&h=400",
    alt: "Hidden coves and secluded beaches near Saint Tropez"
  }
];

export default function ImageGallery() {
  const [selectedImage, setSelectedImage] = useState(0);

  return (
    <section className="mb-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-96 lg:h-[500px]">
        {/* Main Featured Image */}
        <div className="relative overflow-hidden rounded-xl">
          <img 
            src={images[selectedImage].src}
            alt={images[selectedImage].alt}
            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300 cursor-pointer"
            onClick={() => setSelectedImage(0)}
          />
        </div>
        
        {/* Supporting Images Grid */}
        <div className="grid grid-cols-2 gap-4">
          {images.slice(1, 4).map((image, index) => (
            <div 
              key={index + 1}
              className="relative overflow-hidden rounded-xl cursor-pointer"
              onClick={() => setSelectedImage(index + 1)}
            >
              <img 
                src={image.src}
                alt={image.alt}
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
              />
            </div>
          ))}
          
          {/* More Images Button */}
          <div 
            className="relative overflow-hidden rounded-xl cursor-pointer hover:scale-105 transition-transform duration-300"
            onClick={() => setSelectedImage(4)}
          >
            <img 
              src={images[4].src}
              alt={images[4].alt}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
              <div className="text-white text-center">
                <Plus className="h-6 w-6 mx-auto mb-2" />
                <div className="font-semibold">+1</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
