import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, Shield } from "lucide-react";

export default function BookingCard() {
  const [adults, setAdults] = useState("1");
  const [date, setDate] = useState("");
  const [language, setLanguage] = useState("english");

  const handleCheckAvailability = () => {
    console.log("Checking availability for:", { adults, date, language });
    // Here you would typically make an API call to check availability
  };

  return (
    <div className="sticky top-6">
      <Card className="shadow-lg">
        <CardContent className="p-6">
          {/* Pricing Section */}
          <div className="mb-6">
            <div className="flex items-center space-x-2 mb-2">
              <span className="text-sm text-gray-600 line-through">From €69</span>
              <Badge variant="destructive" className="bg-red-500 hover:bg-red-600">
                Save up to 50%
              </Badge>
            </div>
            <div className="flex items-baseline space-x-2">
              <span className="text-3xl font-bold text-gray-900">€35</span>
              <span className="text-gray-600">per person</span>
            </div>
          </div>

          {/* Reserve Badge */}
          <div className="flex items-center space-x-2 mb-6 p-3 bg-gray-50 rounded-lg">
            <Calendar className="text-blue-600 h-5 w-5" />
            <div>
              <div className="font-medium text-gray-900">Reserve now & pay later</div>
              <div className="text-sm text-gray-600">Keep your travel plans flexible — book your spot and pay nothing today.</div>
            </div>
          </div>

          {/* Booking Form */}
          <div className="space-y-4 mb-6">
            {/* Participants Dropdown */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Adults</label>
              <Select value={adults} onValueChange={setAdults}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select adults" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Adult x 1</SelectItem>
                  <SelectItem value="2">Adult x 2</SelectItem>
                  <SelectItem value="3">Adult x 3</SelectItem>
                  <SelectItem value="4">Adult x 4</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Date Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date</label>
              <Select value={date} onValueChange={setDate}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select date" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="today">Today</SelectItem>
                  <SelectItem value="tomorrow">Tomorrow</SelectItem>
                  <SelectItem value="weekend">This weekend</SelectItem>
                  <SelectItem value="next-week">Next week</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Language Selection */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Language</label>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select language" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="english">English</SelectItem>
                  <SelectItem value="french">French</SelectItem>
                  <SelectItem value="german">German</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Check Availability Button */}
          <Button 
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 px-6 rounded-lg transition-colors mb-4"
            onClick={handleCheckAvailability}
          >
            Check availability
          </Button>

          {/* Free Cancellation */}
          <div className="text-center">
            <div className="flex items-center justify-center space-x-2 text-sm text-gray-600">
              <Shield className="text-green-600 h-4 w-4" />
              <span>Free cancellation</span>
            </div>
            <div className="text-xs text-gray-500 mt-1">Cancel up to 24 hours in advance for a full refund</div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
