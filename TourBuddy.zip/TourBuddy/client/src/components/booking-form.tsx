import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";

interface BookingFormProps {
  className?: string;
}

export default function BookingForm({ className }: BookingFormProps) {
  const [city, setCity] = useState("");
  const [beach, setBeach] = useState("");
  const [duration, setDuration] = useState("30");
  const [showConfirmation, setShowConfirmation] = useState(false);

  const { toast } = useToast();
  const isMobile = useIsMobile();

  // Beach options data
  const beachOptions = {
    "frejus": ["Plage de Fréjus", "Plage de Saint-Aygulf"],
    "saint-raphael": ["Plage du Veillat", "Plage de la Baumette", "Calanque du Petit Caneiret"],
    "les-issambres": ["Plage de la Gaillarde", "Plage de San Peïre", "Calanque de Tardieu"],
    "sainte-maxime": ["Plage de la Croisette", "Plage des Éléphants", "Plage de la Nartelle"],
    "saint-tropez": ["Plage de Pampelonne", "Plage des Salins", "Plage de la Bouillabaisse"],
    "gassin": ["Plage du Treizain", "Plage de la Moune", "Plage de Bertaud-Marines"],
    "grimaud": ["Plage de Port Grimaud", "Plage des Cigales", "Plage de Saint-Pons-les-Mûres"],
    "la-croix-valmer": ["Plage du Débarquement", "Plage de Gigaro", "Plage de Sylvabelle"],
    "cavalaire": ["Plage du Centre-Ville", "Plage de Pardigon", "Plage de Bonporteau"]
  };

  // Pricing data
  const pricing = {
    "10": 10,
    "30": 79,
    "60": 159,
    "90": 219
  };

  const getCurrentPrice = () => {
    return pricing[duration as keyof typeof pricing] || 79;
  };

  const generateEmailSubject = () => {
    return encodeURIComponent(`eFoil Booking Request - ${city} (${beach})`);
  };

  const generateEmailBody = () => {
    const currentPrice = getCurrentPrice();
    const body = `Hello Roll'n'Trip team,

I would like to book an eFoil session with the following details:

📍 Location: ${beach}, ${city}
⏱️ Duration: ${duration} minutes
💰 Price: €${currentPrice}

Please confirm availability and send me the booking details.

Thank you!`;
    
    return encodeURIComponent(body);
  };

  const generateSMSBody = () => {
    const currentPrice = getCurrentPrice();
    const body = `Hi! I'd like to book an eFoil session: ${beach}, ${city} - ${duration}min - €${currentPrice}. Please confirm availability.`;
    
    return encodeURIComponent(body);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!city || !beach) {
      toast({
        title: "Missing Information",
        description: "Please select city and beach.",
        variant: "destructive",
      });
      return;
    }

    if (isMobile) {
      // Open SMS on mobile
      const smsUrl = `sms:+33698743339?body=${generateSMSBody()}`;
      window.location.href = smsUrl;
    } else {
      // Open email on desktop
      const emailUrl = `mailto:bookings@rollntrip.com?subject=${generateEmailSubject()}&body=${generateEmailBody()}`;
      window.location.href = emailUrl;
    }

    // Show confirmation
    setShowConfirmation(true);
    
    toast({
      title: "Booking Request Sent!",
      description: isMobile 
        ? "SMS app opened with booking details" 
        : "Email client opened with booking details",
    });
  };

  if (showConfirmation) {
    return (
      <div className={`bg-white rounded-xl shadow-lg p-6 ${className}`}>
        <div className="text-center">
          <div className="text-green-600 text-6xl mb-4">✓</div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Booking Request Sent!</h2>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <p className="text-sm text-green-800">
              {isMobile 
                ? `SMS opened with your booking request for ${beach}, ${city} (${duration} min - €${getCurrentPrice()}). Send the message to contact us!`
                : `Email opened with your booking request for ${beach}, ${city} (${duration} min - €${getCurrentPrice()}). Send the email to complete your booking!`
              }
            </p>
          </div>
          <Button 
            onClick={() => {
              setShowConfirmation(false);
              setCity("");
              setBeach("");
              setDuration("30");
            }}
            className="w-full"
          >
            Book Another Session
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className={`bg-white rounded-xl shadow-lg p-6 sticky top-6 ${className}`}>
      <h2 className="text-2xl font-bold text-center mb-6 bg-gradient-to-r from-black to-gray-600 bg-clip-text text-transparent">
        We bring the boards to you
      </h2>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* City Selection */}
        <div>
          <Label htmlFor="city">Tell us where</Label>
          <Select value={city} onValueChange={(value) => {
            setCity(value);
            setBeach(""); // Reset beach when city changes
          }}>
            <SelectTrigger>
              <SelectValue placeholder="Select a city" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="frejus">Fréjus</SelectItem>
              <SelectItem value="saint-raphael">Saint-Raphaël</SelectItem>
              <SelectItem value="les-issambres">Les Issambres</SelectItem>
              <SelectItem value="sainte-maxime">Sainte-Maxime</SelectItem>
              <SelectItem value="saint-tropez">Saint-Tropez</SelectItem>
              <SelectItem value="gassin">Gassin</SelectItem>
              <SelectItem value="grimaud">Grimaud</SelectItem>
              <SelectItem value="la-croix-valmer">La Croix-Valmer</SelectItem>
              <SelectItem value="cavalaire">Cavalaire-sur-Mer</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Beach Selection */}
        {city && (
          <div>
            <Label htmlFor="beach">Pick your beach</Label>
            <Select value={beach} onValueChange={setBeach}>
              <SelectTrigger>
                <SelectValue placeholder="Select a beach" />
              </SelectTrigger>
              <SelectContent>
                {beachOptions[city as keyof typeof beachOptions]?.map((beachName) => (
                  <SelectItem key={beachName} value={beachName}>
                    {beachName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Duration Selection */}
        <div>
          <Label htmlFor="duration">Session Duration</Label>
          <Select value={duration} onValueChange={setDuration}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="10">10 min - Trial offer</SelectItem>
              <SelectItem value="30">30 min</SelectItem>
              <SelectItem value="60">60 min</SelectItem>
              <SelectItem value="90">90 min</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Price Display */}
        <div className="text-center py-4">
          <div className="text-2xl font-bold bg-gradient-to-r from-black to-gray-600 bg-clip-text text-transparent">
            €{getCurrentPrice()} per person
          </div>
          <div className="text-sm text-gray-600">Max. 6 people</div>
        </div>

        {/* Information about contact method */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
          <p className="text-sm text-blue-800">
            {isMobile 
              ? "📱 Clicking 'Book Session' will open SMS with your booking details"
              : "📧 Clicking 'Book Session' will open your email with booking details"
            }
          </p>
        </div>

        {/* Book Button */}
        <Button 
          type="submit" 
          className="w-full bg-gradient-to-r from-black to-gray-700 hover:from-gray-700 hover:to-black"
        >
          {isMobile ? "Send SMS Booking" : "Send Email Booking"}
        </Button>
      </form>
    </div>
  );
}